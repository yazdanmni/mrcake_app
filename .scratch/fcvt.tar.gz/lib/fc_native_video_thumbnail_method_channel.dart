import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';

import 'fc_native_video_thumbnail_platform_interface.dart';

/// An implementation of [FcNativeVideoThumbnailPlatform] that uses method channels.
class MethodChannelFcNativeVideoThumbnail
    extends FcNativeVideoThumbnailPlatform {
  /// The method channel used to interact with the native platform.
  @visibleForTesting
  final methodChannel = const MethodChannel('fc_native_video_thumbnail');

  @override
  Future<bool> saveThumbnailToFile(
      {required String srcFile,
      required String destFile,
      required int width,
      required int height,
      String? format,
      bool? srcFileUri,
      FcVideoThumbnailTime? at,
      int? quality}) async {
    if (width <= 0 && height <= 0) {
      throw ArgumentError('Invalid width and height');
    }
    return (await methodChannel.invokeMethod<bool?>('saveThumbnailToFile', {
          'srcFile': srcFile,
          'srcFileUri': srcFileUri,
          'destFile': destFile,
          'width': width,
          'height': height,
          'format': _defaultFormat(format),
          'quality': quality,
          ...?at?.toMap(),
        })) ??
        false;
  }

  @override
  Future<Uint8List?> saveThumbnailToBytes(
      {required String srcFile,
      required int width,
      required int height,
      String? format,
      bool? srcFileUri,
      FcVideoThumbnailTime? at,
      int? quality}) {
    if (width <= 0 && height <= 0) {
      throw ArgumentError('Invalid width and height');
    }
    return methodChannel.invokeMethod<Uint8List?>('saveThumbnailToBytes', {
      'srcFile': srcFile,
      'srcFileUri': srcFileUri,
      'width': width,
      'height': height,
      'format': _defaultFormat(format),
      'quality': quality,
      ...?at?.toMap(),
    });
  }

  String _defaultFormat(String? format) {
    return format ?? 'jpeg';
  }
}
